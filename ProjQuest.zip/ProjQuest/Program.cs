﻿using ProjQuest;

ProjUtils.EnableUTF8Encoding();




Menus.StartProgram();